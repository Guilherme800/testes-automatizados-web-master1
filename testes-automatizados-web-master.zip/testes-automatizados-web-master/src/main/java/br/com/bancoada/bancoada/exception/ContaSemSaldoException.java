package br.com.bancoada.bancoada.exception;

public class ContaSemSaldoException extends RuntimeException {

    public ContaSemSaldoException(String msg) {
        super(msg);
    }

}
